var s = function (){
    var b=1;
    var c=2
    return b+c;
}

console.log(s())